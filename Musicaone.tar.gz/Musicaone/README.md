# This is a blank project with a blank stack. 

## The stack includes common utilities for development including tools for adding additional tools to your workspace.

In this workspace you can:

1. Add / remove additional files.
2. Import additional projects from git or subversion.
3. Install additional libraries and tools in the terminal.
4. Author new commands that will executed in the runtime.
5. Use SSH to connect remote clients.
